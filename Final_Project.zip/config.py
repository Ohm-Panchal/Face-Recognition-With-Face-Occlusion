# path imagenes folder
path_images = "images"

# umbral de recnicimiento entre 

threshold = 0.6
